/*
 * case1.h
 *
 *  Created on: 2013��11��6��
 *      Author: chenrui
 */

#ifndef CASE1_H_
#define CASE1_H_

#include "common.h"
void case1_main();
void case1_isr();


#endif /* CASE1_H_ */
