/*
 * case11.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE11_H_
#define CASE11_H_

#include "common.h"

void case11_isr_low();

void case11_isr_high();



#endif /* CASE11_H_ */
