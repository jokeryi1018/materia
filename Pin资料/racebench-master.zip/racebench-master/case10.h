/*
 * case10.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE10_H_
#define CASE10_H_

#include "common.h"


void case10_main();

void case10_isr();


#endif /* CASE10_H_ */
