/*
 * case7.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE7_H_
#define CASE7_H_

#include "common.h"


void case7_main();

void case7_isr();

#endif /* CASE7_H_ */
