/*
 * case5.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE5_H_
#define CASE5_H_


#include "common.h"

void case5_main();
void case5_isr();

#endif /* CASE5_H_ */
