/*
 * case8.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE8_H_
#define CASE8_H_

#include "common.h"



void case8_isr_low();

void case8_isr_high();

void case8_nestedfunc();

#endif /* CASE8_H_ */
