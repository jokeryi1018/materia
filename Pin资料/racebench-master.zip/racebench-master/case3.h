/*
 * case3.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE3_H_
#define CASE3_H_

#include "common.h"

void case3_main();

void case3_isr();

void case3_nestedfunc();

#endif /* CASE3_H_ */
