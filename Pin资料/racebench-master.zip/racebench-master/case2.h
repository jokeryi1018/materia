/*
 * case2.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE2_H_
#define CASE2_H_

#include "common.h"

void case2_main();

void case2_isr();



#endif /* CASE2_H_ */
