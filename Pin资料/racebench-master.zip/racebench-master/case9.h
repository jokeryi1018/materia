/*
 * case9.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE9_H_
#define CASE9_H_

#include "common.h"


void case9_main();

void case9_isr_low();


void case9_isr_high();

#endif /* CASE9_H_ */
