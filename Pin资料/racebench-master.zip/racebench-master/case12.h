/*
 * case12.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE12_H_
#define CASE12_H_

#include "common.h"

void case12_isr_low();

void case12_isr_high();


#endif /* CASE12_H_ */
