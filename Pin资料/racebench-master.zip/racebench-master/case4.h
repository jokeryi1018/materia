/*
 * case4.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE4_H_
#define CASE4_H_

#include "common.h"

void case4_main();

void case4_isr();

#endif /* CASE4_H_ */
