/*
 * case13.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE13_H_
#define CASE13_H_

#include "common.h"

void case13_main();

void case13_isr_low();

void case13_isr_high();

#endif /* CASE13_H_ */
