/*
 * case6.h
 *
 *  Created on: 2013��11��8��
 *      Author: chenrui
 */

#ifndef CASE6_H_
#define CASE6_H_
#include "common.h"


void case6_main();

void case6_isr();


#endif /* CASE6_H_ */
