"# Ablation" 
See BH16USA-PDF-16x9-PMEHTA-Ablation-Tutorial.pdf for details
