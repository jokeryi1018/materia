﻿For standalone version include canvasjs.min.js
For jQuery version include jquery.canvasjs.min.js

** DO NOT include both the files **