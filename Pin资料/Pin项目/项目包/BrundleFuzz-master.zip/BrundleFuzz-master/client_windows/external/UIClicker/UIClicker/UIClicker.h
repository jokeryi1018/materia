//
// In C/C++ the simplest things are just 
// a pain in the ass...
//

DWORD FindProcessByName(LPCWSTR);
BSTR Ansi2Unicode(char *);
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam);
VOID ProcessButtonText(char *);
