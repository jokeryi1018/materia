#ifndef __COMMON_H__
#define __COMMON_H__
#include<string>
#include <map>
#include"queue.h"
#include <list>
bool stringCompareIgnoreCase(std::string lhs,std::string rhs);


#endif