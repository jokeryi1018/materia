class IDA_TypeExporter:
    """
    Por cada tipo que recibimos tenemos que:
    
      - crear una estructura
      - setear en cada uno de los metodos thiscall
      - 
    """
    def __init__(self, types, resolver):
        pass