/*
 * File: Registers.h
 * Author: Agustin Gianni (agustingianni@gmail.com)
 *
 * Created on March 20, 2011, 4:36 PM
 */

#ifndef REGISTERS_H
#define REGISTERS_H

namespace Registers {
const REG *getSubRegisters(REG reg);
}
#endif // REGISTERS_H
