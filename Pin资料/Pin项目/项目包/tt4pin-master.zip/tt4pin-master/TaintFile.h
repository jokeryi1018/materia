#pragma once
#include "ttracer.h"

VOID TaintFile(IMG img, VOID *v);