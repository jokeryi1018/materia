This is a PIN tool that is used to trace tainted data created and
propogating during a executable file running. And tt4pin is just
short for taint tracer for Pin.

The PIN tool is shipped in the source form. You will need to compile it
for your operating system and PIN version.

Copyright tinkerZf