# directory where to save debug files, cannot be empty, do not use trailing /
debugpath = 'log'

# default analysis
defaultchain = 'lazy'

defaultswarmchain = 'swarm'

