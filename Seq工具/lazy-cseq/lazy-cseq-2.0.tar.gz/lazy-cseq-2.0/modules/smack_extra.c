#include "smack.h"
#include <stdlib.h>
