#define __cs_safe_malloc malloc
#define THREADS <insert-maxthreads-here>
#define GUARD(A,B)
#define IF(T,A,B)
#ifndef NULL
#define NULL 0
#endif
